[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT) [![MIT
License](http://img.shields.io/badge/license-MIT-blue.svg?style=flat)](
LICENSE)

<br />

<div align="center">
    <img src="https://github.com/takkii/diamond/blob/main/images/diamond.gif" alt="diamond">
</div>

<br />
<div align="center">
    diamond use <a href="https://github.com/Shougo/deoplete.nvim">deoplete.nvim</a>
</div>

<br />
<div align="center">
    <b><p>diamond is kindness clone, origin totolot.</p></b>
    <p>The Input Completion List Uses a Dictionary for elixir.</p>
</div>

<br />
<div align="center">
    <b> Copyright &copy 2025 Takayuki Kamiyama </b>
</div>
