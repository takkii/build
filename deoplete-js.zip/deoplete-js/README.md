[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT) [![MITLicense](http://img.shields.io/badge/license-MIT-blue.svg?style=flat)](LICENSE) [![GitHub release](https://img.shields.io/github/release/takkii/graze.svg?style=flat)](GitHub) [![GitHub Status](https://img.shields.io/github/last-commit/takkii/graze.svg?style=flat)](GitHub) 

<br />

<div align="center">
    graze use <a href="https://github.com/Shougo/deoplete.nvim">deoplete.nvim</a>
</div>
<br />

<div align="center">
    <b> Rename for lovingyou, graze is kindness clone, origin go_straight/totolot.</b>
</div>
<br />

<div align="center">
    <b> Copyright &copy 2025 Takayuki Kamiyama </b>
</div>
